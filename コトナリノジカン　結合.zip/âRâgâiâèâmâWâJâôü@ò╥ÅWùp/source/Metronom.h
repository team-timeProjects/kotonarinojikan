
#ifndef		__METRONOM_H__
#define	__METRONOM_H__

#include "TimeObject.h"
#include "Campus.h"
//****************************************************************************************
//
//		Metronom�N���X
//
//****************************************************************************************
//class Metronom :public TimeObject
//{
//private:
//
//	static	const	int	METRONOM_MAX = 4;
//	Metronom*		obj[METRONOM_MAX];
//	iex2DObj*		back;
//	iex2DObj*		metronom;
//	iex2DObj*		needle;
//	
//	float		param;		//	��]�p
//	float		height;		//	����
//	float		angle;		//	����
//
//	float		plus_speed;	//	�X�s�[�h���Z�l
//
//public:
//	//	�������E���
//	Metronom(void);
//	~Metronom(void);
//	void	Initialize(void);
//	void	SetObj(int n, int x, int y, float height, float speed);
//
//	//	�X�V
//	void	Update(void);
//
//	//	�`��
//	void	Render(void);
//
//	void	Move(void);		//	����
//};

//****************************************************************************************
#endif // !__METRONOM_H__
