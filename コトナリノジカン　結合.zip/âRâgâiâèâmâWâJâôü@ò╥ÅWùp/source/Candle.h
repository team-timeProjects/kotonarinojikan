
#ifndef __CANDLE_H__
#define	__CANDLE_H__

#include "TimeObject.h"
#include "Campus.h"
//****************************************************************************************
//
//	Candle�N���X
//
//****************************************************************************************
//class Candle :public TimeObject
//{
//private:
//
//	static	const	int	CANDLE_MAX = 4;
//	Candle*			obj[CANDLE_MAX];
//	
//	iex2DObj*		candle;
//	iex2DObj*		fire;
//	iex2DObj*		melt_candle;
//	iex2DObj*		light;
//
//	float		height;		//	����
//
//public:
//	//	�������E���
//	Candle(void);
//	~Candle(void);
//	void	Initialize(void);
//	void	SetObj(int n, int x, int y, float height);
//
//	//	�X�V
//	void	Update(void);
//
//	//	�`��
//	void	Render(void);
//
//	void	Move(void);		//	����
//
//};

//****************************************************************************************
#endif // !__CANDLE_H__
